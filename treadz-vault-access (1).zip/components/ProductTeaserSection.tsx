
import React from 'react';

const products = [
  { id: '1', name: 'OVERSIZED HOODIE "ONYX"', price: '$85', img: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=600' },
  { id: '2', name: 'TECH-CARGO PANTS V1', price: '$120', img: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&q=80&w=600' },
  { id: '3', name: 'GRAPHIC TEE "REBIRTH"', price: '$45', img: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&q=80&w=600' },
];

const ProductTeaserSection: React.FC = () => {
  return (
    <section className="px-4 py-20 max-w-7xl mx-auto">
      <div className="flex justify-between items-end mb-12">
        <h2 className="text-4xl font-black uppercase tracking-tighter">The Teaser</h2>
        <span className="text-zinc-500 font-mono text-sm underline cursor-help">3 ITEMS REVEALED</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {products.map((product) => (
          <div key={product.id} className="group relative cursor-crosshair">
            <div className="aspect-[3/4] overflow-hidden bg-zinc-900 border border-zinc-800">
              <img 
                src={product.img} 
                alt={product.name}
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
              />
            </div>
            <div className="mt-4 flex justify-between items-start">
              <div>
                <h3 className="font-black text-sm uppercase tracking-wider">{product.name}</h3>
                <p className="text-zinc-500 text-xs mt-1">AVAILABLE SOON</p>
              </div>
              <span className="font-mono text-xs text-zinc-400">{product.price}</span>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ProductTeaserSection;
