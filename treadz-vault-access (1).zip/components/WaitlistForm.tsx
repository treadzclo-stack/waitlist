
import React, { useState } from 'react';

const WaitlistForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1200);
  };

  if (submitted) {
    return (
      <div className="bg-white text-black px-8 py-10 rounded-none text-center max-w-xl mx-auto border-4 border-white">
        <h3 className="text-2xl font-black mb-2 uppercase">You're in the Vault.</h3>
        <p className="font-semibold">Check your inbox. We'll send the entry code soon.</p>
      </div>
    );
  }

  return (
    <div id="waitlist" className="max-w-xl mx-auto px-4 py-20">
      <div className="bg-zinc-900 p-8 md:p-12 border border-zinc-800 relative">
        <div className="absolute -top-3 left-4 bg-white text-black px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest">
          Early Access
        </div>
        <h2 className="text-3xl font-black mb-4 uppercase tracking-tighter">Join the Waitlist</h2>
        <p className="text-gray-400 mb-8 leading-relaxed">
          Be the first to secure the upcoming limited release. Subscribers get 30 minutes early access before general release.
        </p>
        <form onSubmit={handleSubmit} className="flex flex-col space-y-4">
          <input
            type="email"
            placeholder="ENTER_EMAIL@DOMAIN.COM"
            className="w-full bg-black border border-zinc-700 p-4 text-white focus:outline-none focus:border-white transition-colors font-mono"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-white text-black font-black py-4 uppercase tracking-widest hover:bg-gray-200 transition-colors flex items-center justify-center disabled:opacity-50"
          >
            {loading ? 'Processing...' : 'Secure My Spot'}
          </button>
        </form>
        <p className="text-[10px] text-zinc-600 mt-4 text-center uppercase tracking-widest">
          By joining, you agree to our terms of vault access.
        </p>
      </div>
    </div>
  );
};

export default WaitlistForm;
