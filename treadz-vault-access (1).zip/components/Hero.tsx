
import React, { useState } from 'react';

const Hero: React.FC = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1500);
  };

  return (
    <section className="relative h-screen w-full flex flex-col items-center justify-center overflow-hidden">
      {/* Background Image: Automotive Noir */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=80&w=2000" 
          className="w-full h-full object-cover grayscale brightness-50 animate-zoom"
          alt="Vintage high-performance car at night"
        />
        <div className="absolute inset-0 bg-black/40 cinematic-overlay"></div>
      </div>
      
      {/* Branding Header */}
      <div className="absolute top-10 text-center z-10">
        <h1 className="text-xl md:text-2xl font-black uppercase tracking-[0.4em] text-white/90">
          TREADZ // VAULT
        </h1>
      </div>

      {/* Main Content: Sold Out UI */}
      <div className="relative z-10 w-full max-w-lg px-6 text-center">
        {!submitted ? (
          <>
            <h2 className="serif-display text-5xl md:text-7xl font-black mb-4 uppercase italic tracking-tighter">
              SOLD OUT
            </h2>
            <p className="text-[10px] md:text-xs font-bold tracking-[0.2em] mb-12 text-white/70 uppercase">
              Sign up for early access to our next drop
            </p>

            <form onSubmit={handleSubmit} className="flex flex-col space-y-4">
              <input
                type="email"
                placeholder="ENTER EMAIL ADDRESS"
                className="w-full bg-white text-black px-6 py-4 text-xs font-bold placeholder:text-gray-400 focus:outline-none uppercase tracking-widest text-center"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <button
                type="submit"
                disabled={loading}
                className="w-full bg-black text-white px-6 py-4 text-xs font-black uppercase tracking-[0.3em] hover:bg-zinc-900 transition-all border border-white/20 disabled:opacity-50"
              >
                {loading ? 'PROCESSING...' : 'SIGN UP'}
              </button>
            </form>
          </>
        ) : (
          <div className="space-y-6 animate-pulse">
            <h2 className="serif-display text-4xl font-black italic">ACCESS GRANTED</h2>
            <p className="text-xs tracking-[0.3em] text-white/70">CHECK YOUR INBOX FOR THE DIGITAL KEYS.</p>
          </div>
        )}

        {/* Links */}
        <div className="mt-12 flex flex-col space-y-4 items-center">
          <button className="text-[9px] uppercase tracking-widest text-white/40 hover:text-white transition-colors">
            Enter using password
          </button>
          <a href="#" className="text-[9px] uppercase tracking-widest text-white/40 hover:text-white underline underline-offset-4 transition-colors">
            Contact Us
          </a>
        </div>
      </div>

      {/* Bottom info */}
      <div className="absolute bottom-10 z-10">
        <p className="text-[8px] tracking-[0.6em] text-white/30 uppercase">
          Tunis // Automotive Inspired // Garments
        </p>
      </div>
    </section>
  );
};

export default Hero;
