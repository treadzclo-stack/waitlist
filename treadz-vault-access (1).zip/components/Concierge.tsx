
import React, { useState, useRef, useEffect } from 'react';
import { getConciergeResponse } from '../services/geminiService';
import { Message } from '../types';

const Concierge: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'TREADZ SYSTEM ONLINE. HOW CAN I ASSIST YOUR JOURNEY?' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsTyping(true);

    const response = await getConciergeResponse(messages, userMsg);
    setMessages(prev => [...prev, { role: 'model', text: response }]);
    setIsTyping(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {isOpen ? (
        <div className="bg-black border border-white/10 w-[320px] md:w-[380px] h-[450px] flex flex-col shadow-[0_0_50px_rgba(255,255,255,0.05)] overflow-hidden backdrop-blur-xl">
          <div className="bg-zinc-900/50 p-4 flex justify-between items-center border-b border-white/5">
            <div className="flex items-center space-x-2">
              <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
              <span className="font-black text-[10px] uppercase tracking-[0.3em]">SYSTEM // CONCIERGE</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-zinc-500 hover:text-white transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
          </div>
          
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-3 text-[10px] ${m.role === 'user' ? 'bg-white text-black font-black' : 'bg-zinc-900 text-zinc-400'} uppercase tracking-widest leading-relaxed`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="text-[9px] text-zinc-500 animate-pulse tracking-[0.2em] uppercase">
                  CALCULATING...
                </div>
              </div>
            )}
          </div>

          <div className="p-4 bg-black flex space-x-2 border-t border-white/5">
            <input
              type="text"
              placeholder="ASK THE PIT BOSS..."
              className="flex-1 bg-zinc-900 border border-white/10 p-3 text-[10px] text-white focus:outline-none focus:border-white/40 transition-all uppercase tracking-widest"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-black text-white p-4 shadow-xl hover:bg-zinc-900 transition-all border border-white/20 group"
        >
          <div className="flex items-center space-x-3">
             <span className="text-[10px] font-black uppercase tracking-[0.3em] opacity-0 group-hover:opacity-100 transition-opacity">Contact System</span>
             <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
          </div>
        </button>
      )}
    </div>
  );
};

export default Concierge;
