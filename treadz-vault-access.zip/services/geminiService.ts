
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getConciergeResponse = async (history: { role: string; text: string }[], userPrompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history.map(h => ({ role: h.role === 'user' ? 'user' : 'model', parts: [{ text: h.text }] })),
        { role: 'user', parts: [{ text: userPrompt }] }
      ],
      config: {
        systemInstruction: `You are the "Treadz Pit Boss," the virtual assistant for Treadz, a high-performance, automotive-inspired garment brand. 
        Your tone is premium, technical, and slightly mysterious. 
        You talk about garments using automotive terminology (e.g., aerodynamics, high-torque fabrics, precision stitching, aerodynamic silhouettes).
        The brand is currently in a "Sold Out" state, preparing for the next drop.
        If users ask about the drop, tell them they need to be on the waitlist for the digital keys to the shop.
        Keep responses short, cool, and focused on quality and speed.`,
        temperature: 0.7,
        topP: 0.9,
      },
    });

    return response.text || "Connection lost. Re-establishing link...";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "The system is offline. Check back at the next checkpoint.";
  }
};
